from django.contrib import admin
from .models import ContactDealer
admin.site.register(ContactDealer)